/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Script/Regular/BasicLatin.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS.MathJax_Script,{32:[0,0,250,0,0],65:[718,8,803,35,1017],66:[708,28,908,31,928],67:[728,26,666,26,819],68:[708,31,774,68,855],69:[708,8,562,46,719],70:[735,36,895,39,990],71:[717,38,610,12,739],72:[718,36,969,29,1241],73:[717,17,809,59,946],74:[718,315,1052,92,1133],75:[717,37,914,29,1204],76:[718,18,874,14,1036],77:[721,50,1080,30,1216],78:[726,36,902,29,1208],79:[707,8,738,96,805],80:[716,38,1013,89,1031],81:[717,17,883,54,885],82:[717,17,850,-3,887],83:[708,36,868,29,1016],84:[735,37,747,92,996],85:[717,17,800,55,960],86:[717,17,622,56,850],87:[718,17,805,46,1026],88:[718,17,944,103,1132],89:[716,17,710,57,959],90:[718,16,821,82,1033]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Script/Regular/BasicLatin.js");

