/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Main/Bold/SupplementalArrowsA.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["MathJax_Main-bold"],{10229:[519,18,1805,64,1741],10230:[519,18,1833,96,1774],10231:[519,18,2126,64,2062],10232:[548,46,1868,64,1804],10233:[548,47,1870,63,1804],10234:[548,47,2126,64,2060],10236:[519,18,1833,65,1774]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Main/Bold/SupplementalArrowsA.js");

